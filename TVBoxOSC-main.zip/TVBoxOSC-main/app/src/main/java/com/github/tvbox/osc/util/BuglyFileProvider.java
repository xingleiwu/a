package com.github.tvbox.osc.util;

import androidx.core.content.FileProvider;

public class BuglyFileProvider extends FileProvider {
}
